const ui = {
  playButton: null,
  pauseButton: null,
  trackTitle: null,
  trackArtist: null,
  libraryInput: null,
  libraryList: null,
  connectCalendarButton: null,
  eventStatus: null,
  navStatus: null,
  alignmentStatus: null,
};

let isPlaying = false;
let calendarConnected = false;

function bindUi() {
  ui.playButton = document.getElementById("play_button");
  ui.pauseButton = document.getElementById("pause_button");
  ui.trackTitle = document.getElementById("track_title");
  ui.trackArtist = document.getElementById("track_artist");
  ui.libraryInput = document.getElementById("library_input");
  ui.libraryList = document.getElementById("library_list");
  ui.connectCalendarButton = document.getElementById("connect_calendar_button");
  ui.eventStatus = document.getElementById("event_status");
  ui.navStatus = document.getElementById("nav_status");
  ui.alignmentStatus = document.getElementById("alignment_status");
}

function setStatus(eventLine, navLine, alignLine) {
  if (eventLine) ui.eventStatus.textContent = eventLine;
  if (navLine) ui.navStatus.textContent = navLine;
  if (alignLine) ui.alignmentStatus.textContent = alignLine;
}

function refreshPlayControls() {
  const hasTrack = Boolean(window.PlayerMusicLibrary.getSelectedTrack());
  ui.playButton.disabled = !hasTrack || isPlaying;
  ui.pauseButton.disabled = !isPlaying;
}

async function connectCalendar() {
  if (!window.GCAL_CONFIG?.CLIENT_ID || !window.GCAL_CONFIG?.API_KEY) {
    setStatus(
      "Config manquante (config.local.js). Verifiez le deploiement GitHub Pages.",
      null,
      null,
    );
    return;
  }
  if (!window.PlayerCalendarAuth.isReady()) {
    setStatus("Google Calendar: initialisation...", null, null);
    return;
  }
  try {
    await window.PlayerCalendarAuth.requestAccess();
    calendarConnected = true;
    ui.connectCalendarButton.textContent = "Google Calendar connecte";
    setStatus("Prochain evenement: pret", null, null);
  } catch (error) {
    setStatus(`Calendar: ${error.message}`, null, null);
  }
}

async function resolveDestinationFromCalendar() {
  if (!calendarConnected) {
    await connectCalendar();
  }
  if (!calendarConnected) return null;

  const event =
    await window.PlayerCalendarNextEvent.fetchNextEventWithLocation();
  if (!event) {
    setStatus(
      "Aucun evenement avec lieu trouve",
      "Navigation: musique centree",
      null,
    );
    return null;
  }

  setStatus(
    `${event.displayLine}\nLieu: ${event.location}`,
    "Navigation: calcul de l'itineraire...",
    null,
  );

  const geo = await window.resolveAddressWithGoogleMaps(event.location);
  return {
    latitude: geo.latitude,
    longitude: geo.longitude,
    label: event.summary,
    address: event.location,
    eventTime: event.timeLabel,
  };
}

async function startPlaybackSession() {
  const track = window.PlayerMusicLibrary.getSelectedTrack();
  const source = window.PlayerMusicLibrary.getTrackSource(track);
  if (!source) return;

  window.initSpatialAudio();
  window.setSpatialAudioSource(source);
  await window.startSpatialMusic();

  isPlaying = true;
  refreshPlayControls();
  ui.trackTitle.textContent = track.name;
  ui.trackArtist.textContent = track.artist || "Collection Murmur";

  try {
    const destination = await resolveDestinationFromCalendar();
    if (destination) {
      await window.PlayerNavigationEngine.start(destination);
      setStatus(
        `${destination.eventTime} — ${destination.label}\nLieu: ${destination.address}`,
        `Navigation: vers ${destination.label}`,
        "Alignement: en cours...",
      );
    } else {
      window.PlayerSpatialNav.start();
    }
  } catch (error) {
    setStatus(null, `Navigation: ${error.message}`, "Musique centree");
    window.PlayerSpatialNav.start();
  }
}

function stopPlaybackSession() {
  window.stopDirectionalTone();
  window.PlayerNavigationEngine.stop();
  isPlaying = false;
  refreshPlayControls();
  const track = window.PlayerMusicLibrary.getSelectedTrack();
  ui.trackArtist.textContent = track?.artist || "Collection Murmur";
  setStatus(null, "Navigation: inactive", "Alignement: —");
}

function showSelectedTrack(track) {
  if (!track) return;
  ui.trackTitle.textContent = track.name;
  ui.trackArtist.textContent = track.artist || "Collection Murmur";
  refreshPlayControls();
}

function initBundledMusic() {
  const catalog = window.MURMUR_BUNDLED_MUSIC;
  if (!catalog?.length) return;

  window.PlayerMusicLibrary.loadBundledCatalog(catalog);
  const track = window.PlayerMusicLibrary.pickRandomTrack();
  window.PlayerMusicLibrary.renderLibraryList(ui.libraryList);
  showSelectedTrack(track);
}

function onLibraryInputChange(event) {
  window.PlayerMusicLibrary.addFiles(event.target.files);
  window.PlayerMusicLibrary.renderLibraryList(ui.libraryList);
  if (window.PlayerMusicLibrary.getTrackCount() === 1) {
    showSelectedTrack(window.PlayerMusicLibrary.selectTrack(0));
  }
}

function initPlayerApp() {
  bindUi();

  ui.libraryInput.addEventListener("change", onLibraryInputChange);
  ui.connectCalendarButton.addEventListener("click", connectCalendar);
  ui.playButton.addEventListener("click", startPlaybackSession);
  ui.pauseButton.addEventListener("click", stopPlaybackSession);

  window.addEventListener("player-track-selected", (event) => {
    if (!isPlaying) showSelectedTrack(event.detail);
    window.PlayerMusicLibrary.renderLibraryList(ui.libraryList);
  });

  initBundledMusic();

  window.addEventListener("player-nav-update", (event) => {
    const { navLine, alignLine } = event.detail;
    setStatus(null, navLine, alignLine);
  });

  window.addEventListener("player-nav-error", (event) => {
    setStatus(null, `Navigation: ${event.detail}`, null);
  });

  window.addEventListener("player-calendar-ready", () => {
    ui.connectCalendarButton.disabled = false;
    if (window.PlayerCalendarAuth.isReady()) {
      setStatus("Prochain evenement: connectez Google Calendar", null, null);
    }
  });

  window.setTimeout(() => {
    if (!window.GCAL_CONFIG?.CLIENT_ID || !window.GCAL_CONFIG?.API_KEY) {
      setStatus(
        "Config manquante — config.local.js introuvable sur le serveur.",
        null,
        null,
      );
      return;
    }
    if (!window.PlayerCalendarAuth.isReady()) {
      setStatus(
        "Google Calendar: echec d'initialisation (origine OAuth ou cle API ?)",
        null,
        null,
      );
    }
  }, 5000);

  refreshPlayControls();
  setStatus("Prochain evenement: connectez Google Calendar", null, null);
}

// Bouton pour connecter le device physique
document
  .getElementById("ble_connect_button")
  ?.addEventListener("click", async () => {
    await window.MurmurBLE.connect();
    window.MurmurBLE.onButtonPress = () => {
      // Remplace par ta fonction play/pause existante
      const audio = document.querySelector("audio") || window._audioElement;
      if (audio?.paused) audio.play();
      else audio?.pause();
    };
  });
document.addEventListener("DOMContentLoaded", initPlayerApp);
